package com.faysal.Jobkhujibd_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobkhujibdBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobkhujibdBackendApplication.class, args);
	}

}
