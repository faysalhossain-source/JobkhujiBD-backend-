package com.faysal.Jobkhujibd_backend.constants;

public enum Role {
    ADMIN,
    EMPLOYER,
    JOBSEEKER
}
